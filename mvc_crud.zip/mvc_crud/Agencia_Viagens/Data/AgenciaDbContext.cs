using Microsoft.EntityFrameworkCore;
using Agencia_Viagens.Models;

namespace Agencia_Viagens.Data
{
    public class AgenciaDbContext : DbContext
    {
        public AgenciaDbContext (DbContextOptions<AgenciaDbContext> opt) : base (opt)
        {

        }

        public DbSet<Destino> Destinos {get;set;}
        public DbSet<Passagem> Passagens {get;set;}

    }
}