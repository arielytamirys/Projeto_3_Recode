using System.ComponentModel.DataAnnotations;

namespace Agencia_Viagens.Models
{
    public class Passagem
    {
        [Key]
        [Required]

        public int Id {get;set;}
        [Required]

        public string Cliente {get;set;}

        [Required]

        public decimal Valor{get;set;}
        [Required]

        public int DestinoId  {get;set;}

        public Destino Destino {get;set;}


    }
}