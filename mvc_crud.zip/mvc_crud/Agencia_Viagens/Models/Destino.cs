using System.ComponentModel.DataAnnotations;

namespace Agencia_Viagens.Models
{
    public class Destino
    {

        [Key]
        [Required]
        public int Id {get;set;}
        [Required]
        public string Cidade {get;set;}

        [Required]
        public string Ida {get;set;}
        [Required]

        public string Volta {get;set;}
        
        
        
    }
}